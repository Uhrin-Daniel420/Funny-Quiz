const question = document.querySelector('#question');
const choices = Array.from(document.querySelectorAll('.choice-text'));
const progressText = document.querySelector('#szamlalo');
const progressText2 = document.querySelector('#life');




let currentQuestion = {}
let acceptingAnswers = true
let questionCounter = 0
let availableQuestions = []



let questions = [

    {question: 'Készen állsz?',
    choice1:'Nem',
    choice2:'Igen',
    choice3:'Talán?',
    choice4:'Nem kérdés',
    answer:2 ,
},
    {question: 'A válasz nagyon nagy',
    choice1:'Elefánt ',
    choice2:'Bolygó',
    choice3:'Nagy',
    choice4:'Kicsi',
    answer: 1,
},
    {question: 'Válasz kicsi',
    choice1:'Hangya',
    choice2:'Kő darab',
    choice3:'Kicsi',
    choice4:'Molekula',
    answer: 4,
},
    {question: 'Szerinted?',
    choice1:'🤷‍♂️',
    choice2:'🤷‍♂️',
    choice3:'🤷‍♂️',
    choice4:'🤷‍♂️',
    answer: 3,
},
    {question: 'Egy törötlábú kátyának hány lába van?',
    choice1:'2',
    choice2:'3',
    choice3:'4',
    choice4:'5',
    answer: 3 ,
},
    {question: 'Miért kell a nyugdíjast oda engedni az ülőhelyedre a buszon?',
    choice1:'Mert elkap és megfőz az üstben',
    choice2:'Mert mérgés',
    choice3:'Mert szegény nem bír állni',
    choice4:'MERT VÁN MINDENHOL HELY DE Ő A TE HELYEDRE PÁLYÁZIK',
    answer: 1 ,
},
{question: '4+6*3 ',
    choice1:'30',
    choice2:'21',
    choice3:'43',
    choice4:'22',
    answer: 4 ,
},
    {question: 'Piros ... Sárga ... Zöld...',
    choice1:'Bruuuuum Bruuuum Brum',
    choice2:'Jaj ne rendőr',
    choice3:'Piros Sárga ... Piros',
    choice4:'Piros ... Sárga ... Zöld ...',
    answer: 3 ,
},
    {question: 'Kivánság kör a választás a tied! Idáig csak a profik jutnak el.',
    choice1:'+1 Kérdés Átugrása',
    choice2:'+1 Élet',
    choice3:'+1 Kérdés',
    choice4:'-1 élet',
    answer: 1,
},
    {question: 'Ilyenkor mivan?',
    choice1:'',
    choice2:'',
    choice3:'',
    choice4:'',
    answer: 2,
},
    {question: 'Keresd meg a pirost',
    choice1:'Alma',
    choice2:'Fű',
    choice3:'Ceruza',
    choice4:'Kék',
    answer: 3 ,
},
    {question: 'Melyik nehezebb?',
    choice1:'1Kg Toll',
    choice2:'1Kg Fém rúd',
    choice3:'Egyiksem',
    choice4:'Mindkettő',
    answer: 4,
},
    {question: 'Leggyorsabb ló',
    choice1:'Faló',
    choice2:'Viziló',
    choice3:'Musztáng',
    choice4:'Olló',
    answer: 2 ,
    
},
    {question: 'Kedvenc Számom',
    choice1:'21',
    choice2:'Despaszító',
    choice3:'47',
    choice4:'Valami random cuc',
    answer: 3 ,
},
    {question: 'Mi a VR?',
    choice1: 'Várni napokig',
    choice2:'Virtuális valoság. ',
    choice3:'Valami retenetes  ',
    choice4:'Vissza vár',
    answer: 1
},
    {question: 'Legnagyobb szám',
    choice1:'∞',
    choice2:'1000000000000000000000',
    choice3:'1',
    choice4:'69',
    answer: 2,
},
    {question: 'Hány karakter van ebben a kérdésben?',
    choice1:'56',
    choice2:'34 ',
    choice3:'1',
    choice4:'31',
    answer: 2,
},
    {question: 'Emberek száma akik csinálták ezt a játékot',
    choice1:'Egy csapat',
    choice2:'Három ember',
    choice3:'Sokan',
    choice4:'Kevesen',
    answer: 1,
},
    {question: 'Mi nem kell a palacsintához',
    choice1:'Acél',
    choice2:'Szodabikabrona',
    choice3:'Serpenyő',
    choice4:'Műanyag',
    answer: 3,
},
    {question: 'Milyen napod van ma?',
    choice1:'Általánosan érzem magam',
    choice2:'Jól érzem magam',
    choice3:' Nagyon Nagyon ideges vagyok',
    choice4:'Kellemesen',
    answer: 3,
},
    {question: 'Mi következi február 31-e után?',
    choice1:'Kérdőjel',
    choice2:'e',
    choice3:'március',
    choice4:'32',
    answer: 2,
},
    {question: 'Hol volt a 6. kérdés válasza',
    choice1:'Itt',
    choice2:'IDK',
    choice3:'Szerintem Itt',
    choice4:'Ja itt',
    answer: 1,
},
    {question: 'Mit kell belerakni egy vödörbe hogy könnyebb legyen?',
    choice1:'Lyukat',
    choice2:'Malacot belet',
    choice3:'Semmit',
    choice4:'Még egy vödröt',
    answer: 3,
},
    {question: 'Milyen hangaja van egy subarunak?',
    choice1:' Vu vuv vuvuvuuuv uvuvuv ',
    choice2:'Tutututu tu u',
    choice3:'trattaratr tar ',
    choice4:'vututtuuututu csit csat dirdur  ',
    answer: 4,
},
    {question: 'A legroszabb pizza feltét',
    choice1:'Beton',
    choice2:'Majom',
    choice3:'Ananász',
    choice4:'Sonka',
    answer: 1 ,
},
    {question: 'Mikor lezs vége a játéknak?',
    choice1:'MOST',
    choice2:'26 kérdés',
    choice3:'100 kérdés',
    choice4:'SOHA',
    answer: 2,
},
    {question: 'Mennyire érezted jól magad? ',
    choice1:'1',
    choice2:'2',
    choice3:'3',
    choice4:'4',
    answer: 4
    }

]

const MAX_QUESTIONS = 26


startGame = () => {
    questionCounter = 0
    life = 3
    availableQuestions = [...questions]
    getNewQuestion()
}
getCurrentQuestion = () =>
{
    
    if(availableQuestions.length === 0 || questionCounter > MAX_QUESTIONS) {
    
        return window.location.assign('vege.html')
    }

    if (life <= 0 ) {
        return window.location.assign('bena.html')
    }
    

    progressText.innerText = ` ${questionCounter}`
    currentQuestion = availableQuestions[questionCounter]
    question.innerText = currentQuestion.question
    progressText2.innerText = ` ${life}`

    choices.forEach(choice => {
        const number = choice.dataset['number']
        choice.innerText = currentQuestion['choice' + number]
    })
    acceptingAnswers = true
    
}

getNewQuestion = () => {
    
    if(availableQuestions.length === 0 || questionCounter > MAX_QUESTIONS) {
    
        return window.location.assign('vege.html')
    }

    if (life <= 0 ) {
        return window.location.assign('bena.html')
    }

    const questionsIndex = questionCounter

    progressText.innerText = ` ${questionCounter}`
    progressText2.innerText = ` ${life}`
    currentQuestion = availableQuestions[questionsIndex]
    question.innerText = currentQuestion.question
    

    choices.forEach(choice => {
        const number = choice.dataset['number']
        choice.innerText = currentQuestion['choice' + number]
    })
    
    acceptingAnswers = true  
    
}
    choices.forEach(choice => {
        choice.addEventListener('click', e => {
            if(!acceptingAnswers) return
    
            acceptingAnswers = false
            const selectedChoice = e.target
            const selectedAnswer = selectedChoice.dataset['number']
    
            let classToApply = selectedAnswer == currentQuestion.answer ? 'correct' : 'incorrect';
    
            selectedChoice.parentElement.classList.add(classToApply)
    
            if (classToApply === 'incorrect' ) {
                life -= 1;
                
                
            console.log(life)
            getCurrentQuestion();
            
            setTimeout(() => {
                selectedChoice.parentElement.classList.remove(classToApply) },500)
    
            } 
            if (classToApply === 'correct' ){
            setTimeout(() => {
                selectedChoice.parentElement.classList.remove(classToApply)
                
                if (classToApply === 'correct' ) {
                    
                    questionCounter++
                    getNewQuestion()
                }
                
    
            }, 200 )
        }
        })
    })



startGame()





